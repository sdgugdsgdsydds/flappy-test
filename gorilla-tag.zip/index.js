const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Bird properties
let birdX = 50;
let birdY = canvas.height / 2;
let birdYVelocity = 0;
let birdRadius = 12;

// Pipe properties
let pipeWidth = 50;
let pipeGap = 150;
let pipeX = canvas.width;
let pipeY = 0;

// Game state
let score = 0;
let isGameOver = false;
let gameOverMessage = "Game Over! Press 'R' to restart";

// Drawing functions
function drawBird() {
  ctx.fillStyle = 'yellow';
  ctx.beginPath(); 
  ctx.arc(birdX, birdY, birdRadius, 0, 2 * Math.PI);
  ctx.fill();
}

function drawPipes() {
  ctx.fillStyle = 'green';
  ctx.fillRect(pipeX, pipeY, pipeWidth, canvas.height / 2 - pipeGap / 2);
  ctx.fillRect(pipeX, canvas.height / 2 + pipeGap / 2, pipeWidth, canvas.height / 2 - pipeGap / 2);
}

function drawScore() {
  ctx.font = '20px Arial';
  ctx.fillStyle = 'white';
  ctx.fillText('Score: ' + score, 10, 30);
}

function drawGameOver() {
  ctx.font = '30px Arial';
  ctx.fillStyle = 'red';
  ctx.fillText(gameOverMessage, canvas.width / 2 - 150, canvas.height / 2);
}

// Game loop
function gameLoop() {
  if (isGameOver) {
    drawGameOver();
    return;
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Bird movement
  birdY += birdYVelocity;
  birdYVelocity += 0.2; 

  // Check for bird hitting top or bottom
  if (birdY + birdRadius > canvas.height || birdY - birdRadius < 0) {
    isGameOver = true;
  }

  // Draw elements
  drawBird();
  drawPipes();
  drawScore();

  // Move pipes
  pipeX -= 2;
  if (pipeX + pipeWidth < 0) {
    pipeX = canvas.width;
    pipeY = Math.random() * (canvas.height - pipeGap - 20) + 20; 
    score++; 
  }

  // Collision detection (basic check)
  if (checkCollision(birdX, birdY, birdRadius, pipeX, pipeY, pipeWidth, canvas.height / 2 - pipeGap / 2) ||
      checkCollision(birdX, birdY, birdRadius, pipeX, canvas.height / 2 + pipeGap / 2, pipeWidth, canvas.height / 2 - pipeGap / 2)) {
    isGameOver = true;
  }

  requestAnimationFrame(gameLoop);
}

function checkCollision(x1, y1, r1, x2, y2, w2, h2) {
  // Simplified collision check (bird circle vs. pipe rectangle)
  return (x1 + r1 > x2 && x1 - r1 < x2 + w2 && 
          y1 + r1 > y2 && y1 - r1 < y2 + h2);
}

// Start the game
gameLoop();

// Event listeners
document.addEventListener('keydown', (event) => {
  if (event.code === 'Space') {
    birdYVelocity = -5;
  }
  if (event.key === 'r' && isGameOver) { // Restart on 'R'
    resetGame();
  }
});

function resetGame() {
  isGameOver = false;
  score = 0;
  birdX = 50;
  birdY = canvas.height / 2;
  birdYVelocity = 0;
  pipeX = canvas.width;
  pipeY = 0;
}